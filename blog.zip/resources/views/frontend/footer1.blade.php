	<footer id="footer"><!--Footer-->
        <div class="footer-top">
			<div class="container">
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2013 E-SHOPPER Inc. All rights reserved.</p>
					<p class="pull-right">Redesigned by <span><a target="_blank" href="http://yehtet.me">Michael Myers</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->