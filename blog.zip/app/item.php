<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class item extends Model
{
    protected $fillable=[
       'codeno',
       'price',
       'no_animal',
       'type_id',
    ];
    public function type()
    {
    	return $this->belongsTo(type::class,'type_id');
    }
}
