@extends('frontend.master')
@section('content')
  @if(session()->has('success_message'))
  <div class="alert alert-success">
  	{{session()->get('success_message')}}
  </div>
  @endif

  @if(Cart::count()>0)

<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">{{Cart::count()}} item(s) in Your Shopping Cart</li>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image"> image</td>
							<td class="item">Item</td>
					        <td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
				            <td>Remove</td>
							<td>Checkout</td>
						</tr>
					</thead>
                    
					@foreach(Cart::content() as $item)
					<div class="cart-table-row">
                         
					<tbody>
						<tr>
							<td class="cart_description">
						    <img class="img-rounded" alt="Cinque Terre" width="300" height="200"src="{{ $item->options->photo}}">  

							</td>
							<td class="cart_description">
								<h4><a href="">{{$item->name}}</a></h4>
								<p></p>
							</td>
							<td class="cart_price">
								<p>{{$item->price}}</p>
							</td>
						    <td class="cart_total">
								<p class="cart_total_price">{{$item->qty}}</p>
							</td>
							
							<td class="cart_total">
								<p class="cart_total_price">{{$item->subtotal}}</p>
							</td>

						   
							<td>
							<form action="{{route('cart.destroy',$item->rowId)}}" method="post" class="d-inline-block">
                               
                                    @csrf
                                    {{method_field('DELETE')}}
                                <button type="submit" class="cart_quantity_delete" href=""><i class="fa fa-times"></i></button>
                            </form>
						    </td>
						    <td>
						    	<a class="btn btn-default check_out" href="{{route('checkout.index')}}">Check Out</a>
						    </td>
						</tr>

						
					</tbody>
				</div>
					@endforeach
				</table>
			
			</div>
	
		</div>
	</section> <!--/#cart_items-->
	@else
	<section id="cart_items">
		<div class="container">
	<H3>No item(s) in Shopping cart!</H3>
</div>
</section>
  @endif
@endsection