<?php $__env->startSection('content'); ?>
   <div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4">Type Form</h4>
                    <form action="<?php echo e(route('type.store')); ?>" method="post" enctype="multipart/form-data">
                           <?php echo csrf_field(); ?>
                        <div class="form-group">
                           <label for="category_id" class="col-md-4 control-label">Type</label>
                           <select name="category_id" class="form-control">
                               <?php $__currentLoopData = $animal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                        </div>
                        <div class="form-group">
                            <label for="inputAddress">Name</label>
                            <input type="text" class="form-control" name="name" required="">
                        </div>
                       
                        <div class="form-group">
                            <label for="inputAddress">Photo</label>
                            <input type="file" name="photo" class="form-control-file <?php echo e($errors->has('photo') ? ' is-invalid' : ''); ?>" />
                            <?php if($errors->has('photo')): ?>
                            <span class="invalid-feedback" role="alert">
                             <strong><?php echo e($errors->first('photo')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        
          
                        <button class="btn btn-primary btn-lg btn-block error-w3l-btn" type="submit">ADD</button>
                    </form>
     </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pet house\blog\resources\views/backend/type.blade.php ENDPATH**/ ?>