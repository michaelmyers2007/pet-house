<?php $__env->startSection('content'); ?>
    <section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol>
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-6">
									<h1><span>WELCome To</span> My Pet</h1>
									
								</div>
								<div class="col-sm-6">
									<img src="usertemplate/images/home/cover.jpg" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>WELCome To</span> My Pet</h1>
									
								</div>
								<div class="col-sm-6">
									<img src="usertemplate/images/home/pet shop.jpg" class="girl img-responsive" alt="" />
								
								</div>
							</div>
							
							<div class="item">
								<div class="col-sm-6">
									<h1><span>WELCome To</span> My Pet</h1>
							
								</div>
								<div class="col-sm-6">
									<img src="usertemplate/images/home/petshop.jpg" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							
						</div>
						
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	<section>
		<div class="container">
			<div class="row">
			
				
				<div class="col-sm-12 padding-right">
					
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Features Items</h2>
						<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="<?php echo e(asset($types->photo)); ?>" alt="" />
											<h2><?php echo e($types->item->codeno); ?></h2>
											<p><?php echo e($types->name); ?></p>
											<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2><?php echo e($types->item->price); ?>ks</h2>
												<p><?php echo e($types->name); ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
										</div>
								</div>
							
							</div>
						</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					   
						
					</div><!--features_items-->
		
			
					<div class="category-tab"><!--category-tab-->
						<h2 class="title text-center">Food</h2>
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#tshirt" data-toggle="tab">Fish</a></li>
								<li><a href="#blazers" data-toggle="tab">Dog</a></li>
								<li><a href="#sunglass" data-toggle="tab">Cat</a></li>
								<li><a href="#kids" data-toggle="tab">Bird</a></li>
								<li><a href="#poloshirt" data-toggle="tab">Other</a></li>
							</ul>
						</div>
							<?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($foods->type->animal->name=='fish'): ?>
						<div class="tab-content">
							<div class="tab-pane fade active in" id="tshirt" >
							
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo e(asset($foods->photo)); ?>" alt="" />
												<h2><?php echo e($foods->perprice); ?>ks</h2>
												<p><?php echo e($foods->name); ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
											
										</div>
									</div>
								</div>
								
							</div>
							  <?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($foods->type->animal->name=='dog'): ?>	
							<div class="tab-pane fade" id="blazers" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo e(asset($foods->photo)); ?>" alt="" />
												<h2><?php echo e($foods->perprice); ?>ks</h2>
												<p><?php echo e($foods->name); ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
											
										</div>
									</div>
								</div>
								
							</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($foods->type->animal->name=='cat'): ?>
							<div class="tab-pane fade" id="sunglass" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo e(asset($foods->photo)); ?>" alt="" />
												<h2><?php echo e($foods->perprice); ?>ks</h2>
												<p><?php echo e($foods->name); ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
											
										</div>
									</div>
								</div>
								
							</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


							<?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($foods->type->animal->name=='bird'): ?>
							<div class="tab-pane fade" id="kids" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo e(asset($foods->photo)); ?>" alt="" />
												<h2><?php echo e($foods->perprice); ?>ks</h2>
												<p><?php echo e($foods->name); ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
											
										</div>
									</div>
								</div>
								
							</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tab-pane fade" id="poloshirt" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo e(asset($foods->photo)); ?>" alt="" />
												<h2><?php echo e($foods->perprice); ?>ks</h2>
												<p><?php echo e($foods->name); ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
											
										</div>
									</div>
								</div>
								
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
					</div><!--/category-tab-->
                     
				


					
				</div>
			</div>
			
		</div>

	</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pet house\blog\resources\views/index1.blade.php ENDPATH**/ ?>