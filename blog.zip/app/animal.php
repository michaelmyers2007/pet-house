<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class animal extends Model
{
      protected $fillable = [
        'name',
        ];
}
