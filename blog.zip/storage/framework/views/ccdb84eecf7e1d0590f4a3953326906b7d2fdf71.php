<?php $__env->startSection('content'); ?>
   
   <section class="py-5 bg-mylight">
   	
      <div class="container">
	  <h4>Creeper</h4>
	    <div class="row">
	    	<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creepers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<?php if($creepers->animal->name=='turtle'): ?>

	    	<div class="col-md-4">
    			<div class="card " style="border-radius: 1rem;">
    				    <a href="<?php echo e(route('type.show',$creepers->id)); ?>" class="mb-2 d-block" style="cursor: pointer !important;text-decoration: none;">
					    <img class="card-img-top" src="<?php echo e(asset($creepers->photo)); ?>" alt="Card image cap">
					  	<div class="card-img-overlay">
					  
							<span class="card-title"><?php echo e($creepers->name); ?></span>
							  
						</div>
					    <div class="card-body">
					    	
					    	 <p class="text-dark"><?php echo e($creepers->name); ?></p>
					    	  <p class="text-dark"><?php echo e($creepers->item->price); ?>

					    	   <p class="text-dark"><?php echo e($creepers->behavior->description); ?></p>
					    	

					    	
						 
							
							
						    <p class="lead small mb-0 text-secondary"><?php echo e($creepers->created_at->toFormattedDateString()); ?></p>
					    </div>
					
					</a>
					

				</div>
    		</div>
    		
	    <?php endif; ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  </div>
      </div>
  </section>
      <hr class="border-secondary">

    
   <section class="py-5 bg-mylight">
   	
      <div class="container">
	  <h4>Cat</h4>
	    <div class="row">
	    	<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creepers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<?php if($creepers->animal->name=='cat'): ?>

	    	<div class="col-md-4">
    			<div class="card " style="border-radius: 1rem;">
    				    <a href="<?php echo e(route('type.show',$creepers->id)); ?>" class="mb-2 d-block" style="cursor: pointer !important;text-decoration: none;">
					    <img class="card-img-top" src="<?php echo e(asset($creepers->photo)); ?>" alt="Card image cap">
					  	<div class="card-img-overlay">
					  
							<span class="card-title"><?php echo e($creepers->name); ?></span>
							  
						</div>
					    <div class="card-body">
					    	
					    	 <p class="text-dark"><?php echo e($creepers->name); ?></p>
					    	  <p class="text-dark"><?php echo e($creepers->item->price); ?>

					    	   <p class="text-dark"><?php echo e($creepers->behavior->description); ?></p>
					    	

					    	
						 
							
							
						    <p class="lead small mb-0 text-secondary"><?php echo e($creepers->created_at->toFormattedDateString()); ?></p>
					    </div>
					
					</a>
					

				</div>
    		</div>
    		
	    <?php endif; ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  </div>
      </div>
  </section>

        <hr class="border-secondary">

    
   <section class="py-5 bg-mylight">
   	
      <div class="container">
	  <h4>Bird</h4>
	    <div class="row">
	    	<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creepers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<?php if($creepers->animal->name=='bird'): ?>

	    	<div class="col-md-4">
    			<div class="card " style="border-radius: 1rem;">
    				    <a href="<?php echo e(route('type.show',$creepers->id)); ?>" class="mb-2 d-block" style="cursor: pointer !important;text-decoration: none;">
					    <img class="card-img-top" src="<?php echo e(asset($creepers->photo)); ?>" alt="Card image cap">
					  	<div class="card-img-overlay">
					  
							<span class="card-title"><?php echo e($creepers->name); ?></span>
							  
						</div>
					    <div class="card-body">
					    	
					    	 <p class="text-dark"><?php echo e($creepers->name); ?></p>
					    	  <p class="text-dark"><?php echo e($creepers->item->price); ?>

					    	   <p class="text-dark"><?php echo e($creepers->behavior->description); ?></p>
					    	

					    	
						 
							
							
						    <p class="lead small mb-0 text-secondary"><?php echo e($creepers->created_at->toFormattedDateString()); ?></p>
					    </div>
					
					</a>
					

				</div>
    		</div>
    		
	    <?php endif; ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  </div>
      </div>
  </section>
        <hr class="border-secondary">

    
   <section class="py-5 bg-mylight">
   	
      <div class="container">
	  <h4>Dog</h4>
	    <div class="row">
	    	<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creepers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<?php if($creepers->animal->name=='dog'): ?>

	    	<div class="col-md-4">
    			<div class="card " style="border-radius: 1rem;">
    				    <a href="<?php echo e(route('type.show',$creepers->id)); ?>" class="mb-2 d-block" style="cursor: pointer !important;text-decoration: none;">
					    <img class="card-img-top" src="<?php echo e(asset($creepers->photo)); ?>" alt="Card image cap">
					  	<div class="card-img-overlay">
					  
							<span class="card-title"><?php echo e($creepers->name); ?></span>
							  
						</div>
					    <div class="card-body">
					    	
					    	 <p class="text-dark"><?php echo e($creepers->name); ?></p>
					    	  <p class="text-dark"><?php echo e($creepers->item->price); ?>

					    	   <p class="text-dark"><?php echo e($creepers->behavior->description); ?></p>
					    	

					    	
						 
							
							
						    <p class="lead small mb-0 text-secondary"><?php echo e($creepers->created_at->toFormattedDateString()); ?></p>
					    </div>
					
					</a>
					

				</div>
    		</div>
    		
	    <?php endif; ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  </div>
      </div>
  </section>
  <section class="py-5 bg-mylight">
   	
      <div class="container">
	  <h4>Dog</h4>
	    <div class="row">
	    	<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creepers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<?php if($creepers->animal->name=='fish'): ?>

	    	<div class="col-md-4">
    			<div class="card " style="border-radius: 1rem;">
    				    <a href="<?php echo e(route('type.show',$creepers->id)); ?>" class="mb-2 d-block" style="cursor: pointer !important;text-decoration: none;">
					    <img class="card-img-top" src="<?php echo e(asset($creepers->photo)); ?>" alt="Card image cap">
					  	<div class="card-img-overlay">
					  
							<span class="card-title"><?php echo e($creepers->name); ?></span>
							  
						</div>
					    <div class="card-body">
					    	
					    	 <p class="text-dark"><?php echo e($creepers->name); ?></p>
					    	  <p class="text-dark"><?php echo e($creepers->item->price); ?>

					    	   <p class="text-dark"><?php echo e($creepers->behavior->description); ?></p>
					    	

					    	
						 
							
							
						    <p class="lead small mb-0 text-secondary"><?php echo e($creepers->created_at->toFormattedDateString()); ?></p>
					    </div>
					
					</a>
					

				</div>
    		</div>
    		
	    <?php endif; ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  </div>
      </div>
  </section>


	 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pet house\blog\resources\views/index.blade.php ENDPATH**/ ?>